const trips = require('../data/trips.json');

const tripsList = (req, res) => {
    res.render('trips', {
        title: 'Travlr Getaways – Trips',
        trips
    });
};

module.exports = {
    tripsList
};
