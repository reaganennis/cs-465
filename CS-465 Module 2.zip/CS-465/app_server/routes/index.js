const express = require('express');
const router = express.Router();
const ctrlTravlr = require('../controllers/travlr');

router.get('/', ctrlTravlr.index);
router.get('/travel', ctrlTravlr.travel);


module.exports = router;


